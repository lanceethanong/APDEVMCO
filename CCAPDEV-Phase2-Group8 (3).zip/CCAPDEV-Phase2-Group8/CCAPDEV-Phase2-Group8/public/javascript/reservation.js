// --- Delete Reservation ---
async function del(id) {
  if (!id) {
    alert("No reservation ID provided.");
    return;
  }

  // Prompt user for confirmation
  if (!confirm("Are you sure you want to delete this reservation? This cannot be undone.")) {
    return;
  }

  try {
    const response = await fetch("/api/reservation/" + id, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      // Move the reservation box from upcoming to past (soft delete/cancel)
      const box = document.querySelector(`.reservation-box button.delete-btn[onclick="del('${id}')"]`)?.closest('.reservation-box');
      if (box) {
        // Update status text
        const statusSpan = box.querySelector('.status');
        if (statusSpan) {
          statusSpan.textContent = 'Cancelled';
          statusSpan.className = 'status red';
        }
        // Remove delete/edit buttons
        const actions = box.querySelector('.actions');
        if (actions) actions.remove();

        // Move the box to past reservations list
        const pastList = document.getElementById('past-reservations-list').querySelector('.reservation-list');
        if (pastList) {
          pastList.appendChild(box);
        } else {
          // fallback: reload if not found
          location.reload();
        }
      } else {
        // fallback: reload if not found (e.g. reservation-list page)
        location.reload();
      }
      // Show the success message
      const msgBox = document.getElementById("reservation-success-message");
      if (msgBox) {
        msgBox.textContent = "Reservation cancelled successfully.";
        msgBox.style.display = "block";
        setTimeout(() => { msgBox.style.display = "none"; }, 3000);
      } else {
        alert("Reservation cancelled successfully.");
      }
    } else {
      let msg = "Failed to cancel reservation.";
      try {
        const err = await response.json();
        msg = err.error || msg;
      } catch (e) {}
      alert(msg);
      console.error('Failed to cancel:', response.status, msg);
    }
  } catch (error) {
    alert("Error cancelling reservation.");
    console.error('Error:', error);
  }
}

// Make sure del is globally available for inline onclick
window.del = del;

// --- Utilities for Edit Modal ---

function pad(n) { return n < 10 ? '0' + n : n; }

function populateTimeDropdowns() {
  const start = 7 * 60; // 7:00 AM in minutes
  const end = 19 * 60; // 7:00 PM
  const times = [];
  for (let mins = start; mins <= end; mins += 30) {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    times.push(`${pad(h)}:${pad(m)}`);
  }
  const timeStart = document.getElementById('edit-time-start');
  const timeEnd = document.getElementById('edit-time-end');
  timeStart.innerHTML = "";
  timeEnd.innerHTML = "";
  times.forEach(t => {
    timeStart.innerHTML += `<option value="${t}">${t}</option>`;
    timeEnd.innerHTML += `<option value="${t}">${t}</option>`;
  });
}

function setEditDateLimits() {
  const today = new Date();
  const min = today.toISOString().split('T')[0];
  const maxDate = new Date(today.getTime() + 6 * 24 * 60 * 60 * 1000); // next 7 days including today
  const max = maxDate.toISOString().split('T')[0];
  const dateInput = document.getElementById('edit-date');
  dateInput.min = min;
  dateInput.max = max;
}

// --- Edit Reservation ---
window.edit = function(id) {
  fetch('/api/reservation/' + id)
    .then(res => res.json())
    .then(data => {
      document.getElementById('edit-id').value = data._id;

      setEditDateLimits();
      populateTimeDropdowns();

      document.getElementById('edit-date').value = data.date ? data.date.split('T')[0] : '';
      document.getElementById('edit-time-start').value = data.time_start || '';
      document.getElementById('edit-time-end').value = data.time_end || '';
      document.getElementById('edit-row').value = data.row || '';
      document.getElementById('edit-column').value = data.column || '';
      document.getElementById('edit-modal').style.display = 'flex';
    });
};

window.closeEditModal = function() {
  document.getElementById('edit-modal').style.display = 'none';
};

document.getElementById('edit-reservation-form').onsubmit = async function(e) {
  e.preventDefault();
  const id = document.getElementById('edit-id').value;
  const date = document.getElementById('edit-date').value;
  const timeStart = document.getElementById('edit-time-start').value;
  const timeEnd = document.getElementById('edit-time-end').value;
  const row = document.getElementById('edit-row').value;
  const column = document.getElementById('edit-column').value;

  // Frontend validation
  if (!date || !timeStart || !timeEnd || !row || !column) {
    alert("All fields are required.");
    return;
  }
  if (timeEnd <= timeStart) {
    alert("End time must be after start time.");
    return;
  }

  // Check if date is within the allowed range
  const today = new Date();
  const minDate = today.toISOString().split('T')[0];
  const maxDate = new Date(today.getTime() + 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  if (date < minDate || date > maxDate) {
    alert("Date must be within the next 7 days.");
    return;
  }

  // Check if time is between 07:00 and 19:00
  const startMins = parseInt(timeStart.split(":")[0]) * 60 + parseInt(timeStart.split(":")[1]);
  const endMins = parseInt(timeEnd.split(":")[0]) * 60 + parseInt(timeEnd.split(":")[1]);
  if (startMins < 420 || startMins > 1140 || endMins < 420 || endMins > 1140) {
    alert("Start and end time must be between 07:00 and 19:00.");
    return;
  }

  const payload = { date, time_start: timeStart, time_end: timeEnd, row, column };
  const res = await fetch('/api/reservation/' + id, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (res.ok) {
    closeEditModal();
    // Update DOM in place:
    const box = document.querySelector(`.reservation-box button.edit-btn[onclick="edit('${id}')"]`)?.closest('.reservation-box');
    if (box) {
      // Update row/column text
      const infoPs = box.querySelectorAll('.info p');
      infoPs.forEach((p) => {
        if (p.innerText.startsWith("Seat:")) {
          p.innerHTML = `<strong>Seat:</strong> Row ${payload.row}, Column ${payload.column}`;
        } else if (p.innerText.startsWith("Date:")) {
          const dateSpan = p.querySelector('.reservation-date');
          if (dateSpan) dateSpan.textContent = payload.date;
        } else if (p.innerText.startsWith("Time:")) {
          p.innerHTML = `<strong>Time:</strong> ${payload.time_start} - ${payload.time_end}`;
        }
      });
    }
    const msgBox = document.getElementById("reservation-success-message");
    if (msgBox) {
      msgBox.textContent = "Reservation updated successfully.";
      msgBox.style.display = "block";
      setTimeout(() => { msgBox.style.display = "none"; }, 3000);
    }
    // Optionally: location.reload();
  } else {
    const err = await res.json();
    alert(err.error || "Failed to edit reservation.");
  }
};