async function del(id) {
  if (!id) {
    alert("No reservation ID provided.");
    return;
  }

  if (!confirm("Are you sure you want to delete this reservation? This cannot be undone.")) {
    return;
  }

  try {
    const response = await fetch("/api/reservation/" + id, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {

      const box = document.querySelector(`.reservation-box button.delete-btn[onclick="del('${id}')"]`)?.closest('.reservation-box');
      if (box) {
        box.parentNode.removeChild(box);
      } else {

        location.reload();
      }
      alert("Reservation deleted successfully.");
    } else {
      let msg = "Failed to delete reservation.";
      try {
        const err = await response.json();
        msg = err.error || msg;
      } catch (e) {}
      alert(msg);
      console.error('Failed to delete:', response.status, msg);
    }
  } catch (error) {
    alert("Error deleting reservation.");
    console.error('Error:', error);
  }
  if (response.ok) {

  const box = document.querySelector(`.reservation-box button.delete-btn[onclick="del('${id}')"]`)?.closest('.reservation-box');
  if (box) {
    box.parentNode.removeChild(box);
  } else {

    location.reload();
  }
  alert("Reservation deleted successfully.");
}
}

window.del = del;