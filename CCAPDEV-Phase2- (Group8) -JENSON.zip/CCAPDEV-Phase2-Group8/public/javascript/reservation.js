async function del(id) {
  if (!id) {
    alert("No reservation ID provided.");
    return;
  }

  if (!confirm("Are you sure you want to delete this reservation? This cannot be undone.")) {
    return;
  }

  try {
    const response = await fetch("/api/reservation/" + id, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      const box = document.querySelector(`.reservation-box button.delete-btn[onclick="del('${id}')"]`)?.closest('.reservation-box');
      if (box) {
        box.parentNode.removeChild(box);
      } else {
        location.reload();
      }
      alert("Reservation deleted successfully.");
    } else {
      let msg = "Failed to delete reservation.";
      try {
        const err = await response.json();
        msg = err.error || msg;
      } catch (e) {}
      alert(msg);
      console.error('Failed to delete:', response.status, msg);
    }
  } catch (error) {
    alert("Error deleting reservation.");
    console.error('Error:', error);
  }
}

async function openEditModal(reservation) {
  const labsResponse = await fetch('/api/labs');
  const labs = await labsResponse.json();
  
  const labName = reservation.lab || '';
  const lab = labs.find(l => `Lab ${l.number} (${l.class})` === labName);
  
  document.getElementById('edit-modal').style.display = 'block';
  document.getElementById('edit-id').value = reservation._id;
  
  // Format date for display (without +1 day adjustment)
  const rawDate = new Date(reservation.date);
  document.getElementById('edit-date').value = rawDate.toISOString().split('T')[0];
  
  document.getElementById('edit-time-start').value = reservation.time_start;
  document.getElementById('edit-time-end').value = reservation.time_end;
  document.getElementById('edit-lab').value = lab ? lab._id : '';
  document.getElementById('edit-row').value = reservation.row;
  document.getElementById('edit-column').value = reservation.column;
}

function closeEditModal() {
  document.getElementById('edit-modal').style.display = 'none';
}

async function edit(id) {
  if (!id) return alert("No reservation ID provided.");

  try {
    const response = await fetch("/api/reservations/" + id);
    if (!response.ok) return alert("Failed to fetch reservation.");
    const reservation = await response.json();
    openEditModal(reservation);
  } catch (error) {
    alert("Error loading reservation for editing.");
  }
}

// Helper function to convert to 24-hour format
function timeTo24(timeStr) {
  const [time, period] = timeStr.split(' ');
  const [hours] = time.split(':').map(Number);
  let hours24 = hours;
  if (period === 'PM' && hours !== 12) hours24 += 12;
  if (period === 'AM' && hours === 12) hours24 = 0;
  return hours24;
}

// Helper function to prepare date for server (Manila time)
function prepareDateForServer(dateStr) {
  const date = new Date(dateStr);
  // Manila is UTC+8
  const manilaOffset = 8 * 60 * 60 * 1000;
  return new Date(date.getTime() + manilaOffset);
}

async function checkIfCurrentReservation(reservationId, labId, row, column, date, time_start, time_end) {
  try {
    const response = await fetch(`/api/reservations/${reservationId}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch reservation: ${response.status}`);
    }
    
    const reservation = await response.json();
    
    // Compare dates in Manila time
    const existingDate = new Date(reservation.date);
    const newDate = prepareDateForServer(date);
    
    // Compare ISO strings (date portion only)
    const existingDateStr = existingDate.toISOString().split('T')[0];
    const newDateStr = newDate.toISOString().split('T')[0];
    
    // Check if this is the same reservation we're editing
    const isSameReservation = (
      (reservation.lab?._id === labId || reservation.lab?.toString() === labId) &&
      reservation.row == row &&
      reservation.column == column &&
      existingDateStr === newDateStr &&
      reservation.time_start === time_start &&
      reservation.time_end === time_end
    );
    
    return isSameReservation;
    
  } catch (error) {
    console.error('Error checking current reservation:', error);
    return false;
  }
}

document.getElementById('edit-reservation-form').addEventListener('submit', async function (e) {
  e.preventDefault();
  
  const formData = {
    id: document.getElementById('edit-id').value,
    date: document.getElementById('edit-date').value,
    time_start: document.getElementById('edit-time-start').value,
    time_end: document.getElementById('edit-time-end').value,
    lab: document.getElementById('edit-lab').value,
    row: parseInt(document.getElementById('edit-row').value),
    column: parseInt(document.getElementById('edit-column').value)
  };

  // Validate time duration
  const startHour = timeTo24(formData.time_start);
  const endHour = timeTo24(formData.time_end);
  if (endHour <= startHour) {
    alert("End time must be after start time");
    return;
  }

  try {
    // First check for availability
    const labResponse = await fetch(`/api/labs/${formData.lab}`);
    const lab = await labResponse.json();
    
    const availabilityResponse = await fetch(
      `/api/labs/${lab.number}/check-availability?date=${formData.date}&time_start=${formData.time_start}&time_end=${formData.time_end}`
    );
    const availability = await availabilityResponse.json();
    
    // Check if the seat is available (not occupied by others)
    const isSeatAvailable = availability.availableSeats.some(seat => 
      seat.row == formData.row && seat.column == formData.column
    );
    
    // Also check if this is our own existing reservation
    const isCurrentReservation = await checkIfCurrentReservation(
      formData.id,
      formData.lab,
      formData.row,
      formData.column,
      formData.date,
      formData.time_start,
      formData.time_end
    );
    
    if (!isSeatAvailable && !isCurrentReservation) {
      alert("This seat is already reserved for the selected time slot. Please choose another seat or time.");
      return;
    }

    // Prepare the date for server (Manila time)
    const serverDate = prepareDateForServer(formData.date);
    formData.date = serverDate.toISOString();

    const res = await fetch("/api/reservations/" + formData.id, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || "Failed to update reservation.");
    }
    
    alert("Reservation updated successfully.");
    closeEditModal();
    location.reload();
  } catch (error) {
    console.error('Update error:', error);
    alert(error.message);
  }
});

window.edit = edit;
window.closeEditModal = closeEditModal;
window.del = del;