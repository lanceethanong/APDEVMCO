async function del(id) {
  if (!id) {
    alert("No reservation ID provided.");
    return;
  }

  if (!confirm("Are you sure you want to delete this reservation? This cannot be undone.")) {
    return;
  }

  try {
    const response = await fetch("/api/reservation/" + id, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      const box = document.querySelector(`.reservation-box button.delete-btn[onclick="del('${id}')"]`)?.closest('.reservation-box');
      if (box) {
        box.parentNode.removeChild(box);
      } else {
        location.reload();
      }
      alert("Reservation deleted successfully.");
    } else {
      let msg = "Failed to delete reservation.";
      try {
        const err = await response.json();
        msg = err.error || msg;
      } catch (e) {}
      alert(msg);
      console.error('Failed to delete:', response.status, msg);
    }
  } catch (error) {
    alert("Error deleting reservation.");
    console.error('Error:', error);
  }
}


async function edit(id) {
  if (!id) {
    alert("No reservation ID provided.");
    return;
  }

  try {
    const response = await fetch("/api/reservations/" + id, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      let msg = `Failed to fetch reservation: ${response.status}`;
      try {
        const err = await response.json();
        msg = err.error || msg;
      } catch (e) {}
      alert(msg);
      return;
    }

    const reservation = await response.json();

    // Check if reservation is already completed
    // Compare current time with reservation end time
    const now = new Date();
    let resvDate = reservation.date;
    if (/^\d{4}-\d{2}-\d{2}$/.test(resvDate)) {
      resvDate = new Date(resvDate + "T00:00:00+08:00");
    } else {
      resvDate = new Date(resvDate);
    }
    const [endHour, endMinute] = reservation.time_end.split(':').map(Number);
    resvDate.setHours(endHour, endMinute, 0, 0);
    if (now >= resvDate) {
      alert("You cannot edit a reservation that has already been completed.");
      return;
    }

    const newDate = prompt("Edit reservation date (YYYY-MM-DD):", reservation.date);
    if (newDate === null) return;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(newDate)) {
      alert("Please enter date in YYYY-MM-DD format.");
      return;
    }

    const newTimeStart = prompt("Edit start time (HH:MM):", reservation.time_start);
    if (newTimeStart === null) return;
    if (!/^\d{2}:\d{2}$/.test(newTimeStart)) {
      alert("Please enter time in HH:MM format.");
      return;
    }

    const newTimeEnd = prompt("Edit end time (HH:MM):", reservation.time_end);
    if (newTimeEnd === null) return;
    if (!/^\d{2}:\d{2}$/.test(newTimeEnd)) {
      alert("Please enter time in HH:MM format.");
      return;
    }

    // Prevent editing if new date/time is in the past
    let newEndDate = new Date(newDate + "T00:00:00+08:00");
    const [newEndHour, newEndMinute] = newTimeEnd.split(':').map(Number);
    newEndDate.setHours(newEndHour, newEndMinute, 0, 0);
    if (now >= newEndDate) {
      alert("You cannot set a reservation to a time that has already passed.");
      return;
    }

    const updateResponse = await fetch("/api/reservations/" + id, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        date: newDate,
        time_start: newTimeStart,
        time_end: newTimeEnd
      })
    });

    if (!updateResponse.ok) {
      let errMsg = "Failed to update reservation.";
      try {
        const err = await updateResponse.json();
        errMsg = err.error || errMsg;
      } catch (e) {
        errMsg += " (Invalid JSON response)";
      }
      alert(errMsg);
      return;
    }

    alert("Reservation updated successfully.");
    location.reload();

  } catch (error) {
    console.error("Error editing reservation:", error);
    alert("An unexpected error occurred while editing the reservation.");
  }
}

window.edit = edit;
window.del = del;